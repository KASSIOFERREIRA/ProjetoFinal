package com.example.android.projetofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class IdentificarClasse extends AppCompatActivity {

    private String ip = "192.98";
    private int[] enderecoIP = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identificar_classe);
        displayMostrarIpDeEntrda();

    }


    public void displayMostrarIpDeEntrda() {
        TextView scoreView = (TextView) findViewById(R.id.seu_ip_entrada);
        Intent intent = getIntent();
        this.ip = intent.getStringExtra("IP");
        scoreView.setText(String.valueOf(ip));
    }

    public void displayDeSaida(String saida){
        TextView scoreView = (TextView) findViewById(R.id.saida_de_erro);
        scoreView.setText(String.valueOf(saida));
    }


    public void verificarClasse(View view) {
        CheckBox checkboxA = (CheckBox) findViewById(R.id.checkbox_classA);
        CheckBox checkboxB = (CheckBox) findViewById(R.id.checkbox_classB);
        CheckBox checkboxC = (CheckBox) findViewById(R.id.checkbox_classC);

        Intent intent = getIntent();
        this.enderecoIP=intent.getIntArrayExtra("ENDERECO_IP");

        Intent intent2 = new Intent ( this, Activity_mascara.class);
        String classe = "";
        String instrucao= "";
        int IdClasse;
        intent.putExtra("IP", ip);
        intent.putExtra("ENDERECO_IP",enderecoIP);

        if(enderecoIP[0] <=126 && checkboxA.isChecked() && !checkboxB.isChecked() && !checkboxC.isChecked()){
            classe = "Classe A";
            IdClasse = 1;
            instrucao = "Como seu ip é de classe A, só o primeiro octeto é reservado para criar novas " +
                    "redes, que equivale a cada 255 na mascara. Os 3 ultimos são reservados para numero de hosts " +
                    "que voce queira criar em sua rede e é representado pelo valor 0 na mascara.\n Agora click na mascara que representa a sua classe:";
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("IP", ip);
            intent2.putExtra("IDCLASSE", IdClasse);
            intent2.putExtra("INSTRUCAO",instrucao);
            intent2.putExtra("ENDERECO_IP", enderecoIP);

            startActivity(intent2);

        }else if (enderecoIP[0] >=128 && enderecoIP[0]<=191 && checkboxB.isChecked() && !checkboxA.isChecked() && !checkboxC.isChecked()){
            classe = "Classe B";
            IdClasse = 2;
            instrucao = "Como seu ip é de classe B, os primeiros 2 octetos são reservado para criar novas " +
                    "redes, que equivale a cada 255 na mascara. Os 2 ultimos são reservados para numero de hosts " +
                    "que voce queira criar em sua rede e é representado pelo valor 0 na mascara.\n Agora click na mascara que representa a sua classe:";
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("IP", ip);
            intent2.putExtra("IDCLASSE", IdClasse);
            intent2.putExtra("INSTRUCAO",instrucao );
            intent2.putExtra("ENDERECO_IP", enderecoIP);


            startActivity(intent2);

        }else if(enderecoIP[0] >191 && enderecoIP[0]<255 && checkboxC.isChecked() && !checkboxB.isChecked() && !checkboxA.isChecked()){
            classe = "Classe C";
            IdClasse = 3;
            instrucao = "Como seu ip é de classe C, os primeiros 3 octetos são reservado para criar novas " +
                    "redes que equivale cada um a 255 na mascara. E apenas o ultimo é reservado para numero de hosts " +
                    "que voce queira criar em sua rede e é representado pelo valor 0 na mascara.\n Agora click na mascara que representa a sua classe:";
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("IP", ip);
            intent2.putExtra("IDCLASSE", IdClasse);
            intent2.putExtra("ENDERECO_IP", enderecoIP);
            intent2.putExtra("INSTRUCAO",instrucao );

            startActivity(intent2);

        }else{
            displayDeSaida("O primeiro octeto do seu IP não pertence a este intervalo!\n " + "Verifique se voce não marcou mais de um intervalo!");

        }
    }




    }

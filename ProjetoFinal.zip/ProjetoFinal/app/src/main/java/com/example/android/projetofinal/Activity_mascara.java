package com.example.android.projetofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Activity_mascara extends AppCompatActivity {
    String ip ;
    String classe;
    String instrucao;
    String mascara;
    int idClass;
    int enderecoIP[] = new int[4];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascara);
        visorDeSaida();
    }
    // Atualizar os dados das views
    public void visorDeSaida(){

        Intent intent = getIntent();
        idClass = intent.getIntExtra("IDCLASSE", idClass);
        enderecoIP=intent.getIntArrayExtra("ENDERECO_IP");

        TextView scoreView1 = (TextView) findViewById(R.id.instrucao_para_mascara);
        this.instrucao=intent.getStringExtra("INSTRUCAO");
        scoreView1.setText(String.valueOf(instrucao));


        TextView scoreView2 = (TextView) findViewById(R.id.seu_ip_entrada);
        this.ip=intent.getStringExtra("IP");
        scoreView2.setText(String.valueOf(ip));

        TextView scoreView3 = (TextView) findViewById(R.id.classe_do_ip);
        this.classe = intent.getStringExtra("CLASSE");
        scoreView3.setText(String.valueOf(classe));
    }


    // Metodos para verificar a mascara da rede, ao clicar no buttom correto.
    public void  botaoClasseA(View view){
        mascara = "255.0.0.0";
        Intent intent = getIntent();


        if( intent.getIntExtra("IDCLASSE", idClass) == 1){

            Intent intent2 = new Intent(this, ActivityEnderecoDeRede.class);
            intent2.putExtra("IP", ip);
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("MASCARA", mascara);
            intent2.putExtra("ENDERECO_IP", enderecoIP);
            intent2.putExtra("IDCLASS", idClass);
            startActivity(intent2);
        }else{
            TextView scoreView4 = (TextView) findViewById(R.id.visor_saida_erro);
            Log.d(classe, "Entrou");
            scoreView4.setText(String.valueOf("A Mascara não corresponde a seu IP!\n " +
                    "Tente novamente!"));
        }
    }


    public void  botaoClasseB(View view){
        mascara = "255.255.0.0";
        Intent intent = getIntent();
        classe = intent.getStringExtra("CLASSE");
        if(intent.getIntExtra("IDCLASSE", idClass) == 2){
            Intent intent2 = new Intent(this, ActivityEnderecoDeRede.class);
            intent2.putExtra("IP", ip);
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("MASCARA", mascara);
            intent2.putExtra("IDCLASS", idClass);
            intent2.putExtra("ENDERECO_IP", enderecoIP);

            startActivity(intent2);
        }else{
            TextView scoreView4 = (TextView) findViewById(R.id.visor_saida_erro);

            scoreView4.setText(String.valueOf("A Mascara não corresponde a seu IP!\n " +
                    "Tente novamente!"));
        }
    }

    public void  botaoClasseC(View view){
        mascara = "255.255.255.0";
        Intent intent = getIntent();
        classe = intent.getStringExtra("CLASSE");

        if(intent.getIntExtra("IDCLASSE", idClass) == 3){
            Intent intent2 = new Intent(this, ActivityEnderecoDeRede.class);
            intent2.putExtra("IP", ip);
            intent2.putExtra("CLASSE", classe);
            intent2.putExtra("MASCARA", mascara);
            intent2.putExtra("IDCLASS", idClass);
            intent2.putExtra("ENDERECO_IP", enderecoIP);
            startActivity(intent2);
        }else{
            TextView scoreView4 = (TextView) findViewById(R.id.visor_saida_erro);

            scoreView4.setText(String.valueOf("A Mascara não corresponde a seu IP!\n " +
                    "Tente novamente!"));
        }
    }

}

package com.example.android.projetofinal;


        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String ip;
    private int enderecoIP[] = new int[4];
    private boolean validar = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayValidarIp(String entrada) {
        TextView scoreView = (TextView) findViewById(R.id.visor_de_saida);
        scoreView.setText(String.valueOf(entrada));
    }
    //Metodo para validar o IP e converter o tipo.
    public String validarIp(String ip){

        String Message = "";
        String str = "";
        int cont = 0;
        for (int i = 0; i<ip.length(); i++){
            if(ip.charAt(i)!= '.'){
                str+=ip.charAt(i);
            }
            if (ip.charAt(i)=='.'){
                enderecoIP[cont] = Integer.parseInt(str);
                str="";
                cont+=1;
            }
        }
        enderecoIP[3] = Integer.parseInt(str);


        for(int i=0; i<4; i++){
            if(enderecoIP[i]<0 || enderecoIP[i]> 255){
                Message= "Ip invalido!\n" +
                        "Os valores de cada octeto devem estar entre 0 a 255";
                validar=false;



            }
        }



        return Message;


    }

    public void activityIndentificarClasse(View view) {
            EditText ipDeEntrada = (EditText)findViewById(R.id.ip_de_entrada);
            ip = ipDeEntrada.getText().toString();
            displayValidarIp(validarIp(ip));

            if(validar == true){
                Intent intent = new Intent ( this, IdentificarClasse.class);
                intent.putExtra("IP", ip);
                intent.putExtra("ENDERECO_IP",enderecoIP);

                startActivity(intent);


            }
            validar = true;


    }






}
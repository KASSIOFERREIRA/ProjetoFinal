package com.example.android.projetofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActivityEnderecoDeRede extends AppCompatActivity {
    String ip;
    private String classe;
    private String mascara;
    private int enderecoIP[] = new int[4];
    int idClasse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_endereco_de_rede);
        alterarDados();
    }


    public void alterarDados(){

        Intent intent = getIntent();
        //Atualizar as textViews
        TextView scoreView1 = (TextView) findViewById(R.id.seu_ip);
        scoreView1.setText(String.valueOf(intent.getStringExtra("IP")));

        TextView scoreView2 = (TextView) findViewById(R.id.classe);
        scoreView2.setText(String.valueOf(intent.getStringExtra("CLASSE")));

        TextView scoreView3 = (TextView) findViewById(R.id.mascara);
        scoreView3.setText(String.valueOf(intent.getStringExtra("MASCARA")));



        enderecoIP = intent.getIntArrayExtra("ENDERECO_IP");

        //Altera os textos dos buttons de acordo com a classe
        // Classe A
        if(intent.getIntExtra("IDCLASS",idClasse)== 1) {
            Button scoreView4 = (Button) findViewById(R.id.botao_rede2);
            scoreView4.setText(String.valueOf(enderecoIP[0] + "." + "20.1.0"));

            Button scoreView5 = (Button) findViewById(R.id.botao_rede1);
            scoreView5.setText(String.valueOf(enderecoIP[0] + "." + "0.0.0"));

            Button scoreView6 = (Button) findViewById(R.id.botao_rede3);
            scoreView6.setText(String.valueOf(enderecoIP[0] + "." + "255.255.255"));
        }

        //Classe B
        if(intent.getIntExtra("IDCLASS",idClasse)== 2) {
            Button scoreView7 = (Button) findViewById(R.id.botao_rede2);
            scoreView7.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + ".1.25"));

            Button scoreView8 = (Button) findViewById(R.id.botao_rede1);
            scoreView8.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + ".0.0"));

            Button scoreView9 = (Button) findViewById(R.id.botao_rede3);
            scoreView9.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + ".10.255"));
        }

        //Classe C
        if(intent.getIntExtra("IDCLASS",idClasse)== 3) {
            Button scoreView10 = (Button) findViewById(R.id.botao_rede2);
            scoreView10.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".25"));

            Button scoreView11 = (Button) findViewById(R.id.botao_rede1);
            scoreView11.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".0"));

            Button scoreView12 = (Button) findViewById(R.id.botao_rede3);
            scoreView12.setText(String.valueOf(enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".255"));
        }






    }
    //Metodos para verificar os Buttons que esta com o enderço de rede correto.
    public void clickNoBotao1(View view){
        String str1 = enderecoIP[0]+".0.0.0";
        String str2 = enderecoIP[0] + "." + enderecoIP[1] + ".0.0";
        String str3 = enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".0";
        Intent intent2 = getIntent();
        TextView scoreView = (TextView) findViewById(R.id.saida_erro);

        Button scoreView11 = (Button) findViewById(R.id.botao_rede1);
        String textoDoBotao = String.valueOf(scoreView11.getText());

        if(intent2.getIntExtra("IDCLASS",idClasse) == 1){
              if(textoDoBotao == str1){
                  Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                  startActivity(intent);
              }else{
                  scoreView.setText(String.valueOf("Este IP não representa o endereço de rede!\n "+"Tente novamente!"));
              }


        }

        if(intent2.getIntExtra("IDCLASS",idClasse) == 2){
            if(textoDoBotao == str2){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);

            }else{
                scoreView.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }

        if(intent2.getIntExtra("IDCLASS",idClasse) == 3){
            if(textoDoBotao == str3){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }


    }



    public void clickNoBotao2(View view){
        Intent intent2 = getIntent();
        String str1 = enderecoIP[0]+".0.0.0";
        String str2 = enderecoIP[0] + "." + enderecoIP[1] + ".0.0";
        String str3 = enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".0";
        Button scoreView11 = (Button) findViewById(R.id.botao_rede2);
        TextView scoreView2 = (TextView) findViewById(R.id.saida_erro);
        String textoDoBotao = String.valueOf(scoreView11.getText());

        if(intent2.getIntExtra("IDCLASS",idClasse)== 1){
            if(textoDoBotao == str1){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }

        if(intent2.getIntExtra("IDCLASS",idClasse) == 2){
            if(textoDoBotao == (str2)){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }

        if(intent2.getIntExtra("IDCLASS",idClasse)== 3){
            if(textoDoBotao == str3){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }


    }


    public void clickNoBotao3(View view){
        Intent intent2 = getIntent();
        String str1 = enderecoIP[0]+".0.0.0";
        String str2 = enderecoIP[0] + "." + enderecoIP[1] + ".0.0";
        String str3 = enderecoIP[0] + "." + enderecoIP[1] + "." + enderecoIP[2] + ".0";
        Button scoreView11 = (Button) findViewById(R.id.botao_rede3);
        TextView scoreView2 = (TextView) findViewById(R.id.saida_erro);
        String textoDoBotao = String.valueOf(scoreView11.getText());
        if(intent2.getIntExtra("IDCLASS",idClasse) == 1){
            if(textoDoBotao == str1){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }

        if(intent2.getIntExtra("IDCLASS",idClasse)== 2){
            if(textoDoBotao == str2){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }

        if(intent2.getIntExtra("IDCLASS",idClasse) == 3){
            if(textoDoBotao == str3){
                Intent intent = new Intent(this, ActivityQuantidadeDeHosts.class);
                startActivity(intent);
            }else{
                scoreView2.setText(String.valueOf("Este IP não representa o endereço de rede!\n " + "Tente novamente!"));
            }
        }


    }
}

package com.example.android.projetofinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayValidarIp(String entrada) {
        TextView scoreView = (TextView) findViewById(R.id.visor_de_saida);
        scoreView.setText(String.valueOf(entrada));
    }

    public void submitOrder(View view){
        EditText ipDeEntrada = (EditText)findViewById(R.id.ip_de_entrada);
        ip = ipDeEntrada.toString();
        displayValidarIp(ip);
    }






}
